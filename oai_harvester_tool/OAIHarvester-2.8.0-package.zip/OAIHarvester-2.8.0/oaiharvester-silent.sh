java -jar OAIHarvester.jar -confFile=conf/silent.properties
